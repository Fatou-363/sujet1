package controllers;

import play.mvc.*;

public class HomeController extends Controller {

    public Result index() {
        return ok(views.html.index.render());
    }

    public Result helloworld() {
        return ok(views.html.helloworld.render("Lilou"));
  }
    
  public Result helloworld(String fname) {
       return ok(views.html.helloworld.render(fname));
  }
    
}
